import { Component } from '@angular/core';

@Component({
  selector: 'app-galary',
  standalone: true,
  imports: [],
  templateUrl: './galary.component.html',
  styleUrl: './galary.component.css'
})
export class GalaryComponent {

}
