import { Component, OnInit } from '@angular/core';
import { ApiserveService } from '../apiserve.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-apicomp',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './apicomp.component.html',
  styleUrl: './apicomp.component.css'
})
export class ApicompComponent implements OnInit {

  constructor(private _service:ApiserveService) {
  }
  products:any=[];
  ngOnInit() {
    return  this._service.getAllProducts().subscribe(res=>{
      console.log(res)
         this.products=res;

    },err=>{})
   
  }
   
}


