import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiserveService } from '../apiserve.service'; // Adjust the path as needed
import { Product } from '../product'; // Adjust the path as needed

 
@Component({
  selector: 'app-view-id',
  templateUrl: './view-id.component.html',
  styleUrls: ['./view-id.component.css']
})
 
export class ViewProductComponent {
  product: Product | undefined;
  productId: number | undefined;
 
  constructor(private productService: ApiserveService) {}
 
  fetchProductDetails(): void {
    if (this.productId) {
      this.productService.getProductById(this.productId).subscribe(product => {
        this.product = product;
      });
    }
  }
}
