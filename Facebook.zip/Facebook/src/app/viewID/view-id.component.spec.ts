import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewIDComponent } from './view-id.component';

describe('ViewIDComponent', () => {
  let component: ViewIDComponent;
  let fixture: ComponentFixture<ViewIDComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewIDComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewIDComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
