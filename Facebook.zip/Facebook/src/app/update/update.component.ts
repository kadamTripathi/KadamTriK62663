import { Component } from '@angular/core';
import { ApiserveService } from '../apiserve.service'; // Adjust the path as needed
import { Product } from '../product'; // Adjust the path as needed
import { Router } from '@angular/router';
@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent {
  product=new Product()
  constructor(private _route:Router,private _service:ApiserveService) { }  
 
  ngOnInit(): void {
  }
 
  edituserformsubmit(){
    this._service.updateProduct(this.product).subscribe(
      data=>{
        console.log("data added ");
        this._route.navigate(['productlist'])
    },
      error=>console.log("error")
    )
  }
  gotolist(){
    console.log("working clicking in add component ")
  }
 
 
 
}