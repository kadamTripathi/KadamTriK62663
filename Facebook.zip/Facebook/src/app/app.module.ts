import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
 
import { FormsModule } from '@angular/forms';
 
import { AppComponent} from './app.component';
import { AddComponent } from './add/add.component';
import {  HttpClientModule } from '@angular/common/http';
import { ApiserveService } from './apiserve.service';
import { DeleComponent } from './dele/dele.component';
import { viewComponent } from './view/view.component';
import { UpdateComponent } from './update/update.component';
 
@NgModule({
  declarations: [ 
   DeleComponent,
   AddComponent,
   viewComponent,
   UpdateComponent
  ],
  imports: [
    BrowserModule,
    FormsModule// Import FormsModule here
  ],
   
 
 
  providers: [ApiserveService],
 
})
export class AppModule { }