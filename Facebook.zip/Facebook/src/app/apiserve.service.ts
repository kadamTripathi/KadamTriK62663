import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ApiserveService {

  constructor(private _http:HttpClient) { }
  getAllProducts():Observable<any>{
    return  this._http.get<any>("http://localhost:9999/getProd");
  }
  addproductToRemote(product :Product):Observable<any>{
    console.log(product ,"Hi Boss");
    return this._http.post<any>("http://localhost:9999/addProd",product);
    
  }
  private baseUrl="http://localhost:9999/deleteProd";
    deleteuserserv(id: number): Observable<any> {
      return this._http.delete("http://localhost:9999/deleteProd/"+`${id}`, { responseType: 'text' });
  }
  getProductById(id: number): Observable<Product> {
    const url = `${"http://localhost:9999/getProd"}/${id}`;
    return this._http.get<Product>(url);
  }
  updateProduct(product: Product): Observable<Product> {
    const url = "http://localhost:9999/updateProd";
    return this._http.put<Product>(url, product);
  }
}
