import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { HomeComponent } from './home/home.component';
import { GalaryComponent } from './galary/galary.component';
import { ApicompComponent } from './apicomp/apicomp.component';
import { DeleComponent } from './dele/dele.component';
import { AddComponent } from './add/add.component';
import { viewComponent } from './view/view.component';
import { UpdateComponent } from './update/update.component';

export const routes: Routes = [
    {
        path:'login',
        component: LoginComponent
    },
    {
        path: 'signup',
        component: SignupComponent
    },
    {
        path:'home',
        component: HomeComponent
    },
    {
        path:'galary',
        component:GalaryComponent
    },
    {
        path:'api',
        component:ApicompComponent
    },
    {
        path:'deleteuser',component:DeleComponent
    },
    {
        path:'add',component:AddComponent
    },
    {
        path:'viewID',component:viewComponent
    },
    {
        path:'update',component:UpdateComponent
    }
];
