export class Product {
    pid: any;
    pname: any;
    price: any;
    desc: any;
    id: any;
}