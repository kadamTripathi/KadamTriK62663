
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiserveService } from '../apiserve.service';
import { Product } from '../product';
import { NgModule } from '@angular/core';
 
 
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
product=new Product()
  constructor(private _route:Router,private _service:ApiserveService) { }  
 
  ngOnInit(): void {
  }
 
  adduserformsubmit(){
    this._service.addproductToRemote(this.product).subscribe(
      data=>{
        console.log("data added ");
        this._route.navigate(['productlist'])
    },
      error=>console.log("error")
    )
  }
  gotolist(){
    console.log("working clicking in add component ")
  }
 
 
 
}
