import { Component } from '@angular/core';
import { ApiserveService } from '../apiserve.service'; // Adjust the path as needed
import { Product } from '../product'; // Adjust the path as needed

 
@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
 
export class viewComponent {
  product: Product | undefined;
  productId: number | undefined;
 
  constructor(private productService: ApiserveService) {}
 
  fetchProductDetails(): void {
    if (this.productId) {
      this.productService.getProductById(this.productId).subscribe(product => {
        this.product = product;
      });
    }
  }
}
